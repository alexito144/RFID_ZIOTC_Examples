#!/bin/bash
cd /apps
export VERSION=1.0.0
python FX-temp-calc.py &
