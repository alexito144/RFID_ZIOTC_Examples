#!/bin/bash
kill -2 `ps -ef 2> /dev/null | grep python | grep FX-temp-calc.py | awk '{ print $2 }'`
